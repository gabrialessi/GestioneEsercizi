﻿using System.Windows.Controls;

namespace GestioneEsercizi.Views
{
    public partial class ClasseView : UserControl
    {
        public ClasseView() => InitializeComponent();
    }
}