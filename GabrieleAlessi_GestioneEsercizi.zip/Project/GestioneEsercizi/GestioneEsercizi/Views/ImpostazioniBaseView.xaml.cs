﻿using System.Windows.Controls;

namespace GestioneEsercizi.Views
{
    public partial class ImpostazioniBaseView : UserControl
    {
        public ImpostazioniBaseView() => InitializeComponent();
    }
}