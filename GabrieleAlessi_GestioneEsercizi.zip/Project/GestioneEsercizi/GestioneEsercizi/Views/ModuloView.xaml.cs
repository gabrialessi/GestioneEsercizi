﻿using System.Windows.Controls;

namespace GestioneEsercizi.Views
{
    public partial class ModuloView : UserControl
    {
        public ModuloView() => InitializeComponent();
    }
}
