﻿using System.Windows.Controls;

namespace GestioneEsercizi.Views
{
    public partial class BenvenutoView : UserControl
    {
        public BenvenutoView() => InitializeComponent();
    }
}