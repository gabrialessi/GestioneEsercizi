﻿using System.Windows.Controls;

namespace GestioneEsercizi.Views
{
    public partial class ProvaView : UserControl
    {
        public ProvaView() => InitializeComponent();
    }
}