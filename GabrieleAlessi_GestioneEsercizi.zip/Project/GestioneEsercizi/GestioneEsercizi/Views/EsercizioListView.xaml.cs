﻿using System.Windows.Controls;

namespace GestioneEsercizi.Views
{
    public partial class EsercizioListView : UserControl
    {
        public EsercizioListView() => InitializeComponent();
    }
}