﻿using System.Windows.Controls;

namespace GestioneEsercizi.Views
{
    public partial class TematicaView : UserControl
    {
        public TematicaView() => InitializeComponent();
    }
}