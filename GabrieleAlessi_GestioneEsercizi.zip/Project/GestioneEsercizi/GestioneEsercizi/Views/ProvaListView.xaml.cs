﻿using System.Windows.Controls;

namespace GestioneEsercizi.Views
{
    public partial class ProvaListView : UserControl
    {
        public ProvaListView() => InitializeComponent();
    }
}