# Analisi iniziale

## Domande

Si può usare VS2019?  
**Sì, a patto che non ci siano differenze se la soluzione fosse stata fatta con VS2017.**

Svolgimento moduli delle varie classi?  
**Schermata delle impostazioni di base in cui si mostrano le generalità, come ad esempio i vari moduli e le classi.**

Cosa si intende con "ricerca/visione generale"?  
**Bisogna avere una schermata con il riassunto di ciò che si è prodotto finora nelle impostazioni di base.**

Quante maschere/schermate sono in totale?  
**Dipende, si può anche avere una schermata in cui si naviga dal menu per entrare nella maschera voluta.**

Cosa si intende con drag&drop per la scelta degli esercizi?  
**Si intende la possibilità di trascinare files di testo o immagini in cui ci sono già gli esercizi definiti.**

Come deve essere formato e di che tipo è il documento generato? Qual'è la sua struttura?  
**Si può usare un documento RFT per semplificare la generazione dell'esercizio. La struttura comprende titolo, data, classe e poi un eventuale immagine/diagramma con del testo.**

Per eseguire tutto il lavoro sono sufficienti solo i componenti del pattern MVVM?  
**Sì perché è una semplice applicazione in cui ci potrebbe essere un piccolo database.**

Il programma serve solo per gli esercizi delle prove o anche per esercizi in classe?  
**Alla fine non ci sono molte differenze tra una prova e un esercizio in classe, quindi si possono fare entrambi.**

Formato diari e documentazione (MarkDown)?  
**I diari ok, la documentazione in Word.**