﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08_CoffeeShop.DA.Model
{
    public enum Country
    {
        Brasile,
        Ecuador,
        Etiopia,
        Vietnam,
        Colombia,
        Peru,
        Messico,
        Honduras,
        India,
        Indonesia,
        Guatemala
    }
}
