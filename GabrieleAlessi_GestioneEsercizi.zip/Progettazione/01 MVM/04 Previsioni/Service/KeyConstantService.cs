﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Previsioni.Service
{
    public class KeyConstantService : IKeyService
    {
        public string GetKey()
        {
            return "66354f151b8ac37db88ad7dcd547b5c0";
        }
    }
}
