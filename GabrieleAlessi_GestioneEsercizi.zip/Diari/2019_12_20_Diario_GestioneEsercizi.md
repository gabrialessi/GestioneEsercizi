# Gestione Esercizi | Diario di lavoro - 20.12.2019

##### Gabriele Alessi

### Canobbio, 20.12.2019

## Lavori svolti

Durante questa giornata ho consegnato il progetto.
