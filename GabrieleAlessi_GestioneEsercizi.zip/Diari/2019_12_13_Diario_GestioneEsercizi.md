# Gestione Esercizi | Diario di lavoro - 13.12.2019

##### Gabriele Alessi

### Canobbio, 13.12.2019

## Lavori svolti

Durante questa giornata ho principalmente lavorato alla documentazione e in generale alla conclusione del progetto.

Il seguente è un esempio di test case:

![Consuntivo](../Documentazione/Immagini/TestCase.png)

Inoltre ho concluso il capitolo 6 (Conclusioni) e sono già a buon punto per quanto riguarda la consegna della documentazione.

L'unica cosa che manca è l'implementazione dei problemi riscontrati come scritto nei diari dei giorni scorsi. Per questo ho inviato una mail al docente per chiedere aiuto a causa della sua assenza. Quindi spero di finire almeno l'EsercizioViewModel risolvendo quel problema.

| Orario | Lavori svolti |
| - | - |
|13:15 - 16:30 | Documentazione |

## Problemi riscontrati e soluzioni adottate

Nessun problema riscontrato.

## Punto della situazione rispetto alla pianificazione

In linea con la pianificazione.

## Programma di massima per la prossima giornata di lavoro

Conclusione implementazione, documentazione.
