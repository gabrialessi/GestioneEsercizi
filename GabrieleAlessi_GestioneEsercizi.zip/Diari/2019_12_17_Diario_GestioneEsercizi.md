# Gestione Esercizi | Diario di lavoro - 17.12.2019

##### Gabriele Alessi

### Canobbio, 17.12.2019

## Lavori svolti

Oggi ho continuato lavorando alla documentazione del progetto. Prima di tutto ho riguardato tutti i capitoli precedenti a quelli dell'implementazione così da essere sicuro che non ci siano errori. Poi ho proseguito concludendo i vari Models, ViewModels e Views.

Per la prossima lezione dovrei riuscire a concludere tutto e prepararmi per consegnare.

| Orario | Lavori svolti |
| - | - |
|13:15 - 16:30 | Documentazione |

## Problemi riscontrati e soluzioni adottate

Nessun problema riscontrato.

## Punto della situazione rispetto alla pianificazione

In linea con la pianificazione.

## Programma di massima per la prossima giornata di lavoro

Conclusione progetto.
