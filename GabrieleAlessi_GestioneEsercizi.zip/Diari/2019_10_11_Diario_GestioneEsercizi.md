# Gestione Esercizi | Diario di lavoro - 11.10.2019

##### Gabriele Alessi

### Canobbio, 11.10.2019

## Lavori svolti

Oggi durante le prime due ore c'è la stata la presentazione del docente Valsangiacomo riguardo agli esami LPI.

Nelle ore successive ho riguardato il progetto (soprattutto la documentazione) in tenendo conto delle specifiche spiegate e ho approfittato del tempo rimanente per finire un lavoro di un altro modulo.

Quindi riassumendo questa è stata una giornata abbastanza tranquilla dove non ho avuto l'occasione di lavorare molto sull'implementazione.  
Per la prossima settimana l'obiettivo sarebbe di concludere i ViewModels e iniziare le Views dopo aver consultato il docente.

| Orario | Lavori svolti |
| - | - |
|13:15 - 14:45 | Presentazione esami di diploma |
|15:00 - 16:30 | Documentazione |

## Problemi riscontrati e soluzioni adottate

Nessun problema riscontrato.

## Punto della situazione rispetto alla pianificazione

Abbastanza in anticipo rispetto alla pianificazione.

## Programma di massima per la prossima giornata di lavoro

Implementazione, documentazione.
