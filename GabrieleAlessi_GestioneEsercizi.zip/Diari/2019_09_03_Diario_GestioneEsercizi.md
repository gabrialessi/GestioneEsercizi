# Gestione Esercizi | Diario di lavoro - 03.09.2019
##### Gabriele Alessi
### Canobbio, 03.09.2019

## Lavori svolti

I docenti ci hanno esposto i vari progetti e ognuno ha scelto il proprio. Il mio responsabile è il docente Bernasconi e durante questo semestre lavorerò allo sviluppo di un'applicazione che gestisce gli esercizi delle prove formandone un documento.  
Dopo che abbiamo scelto ci è stato consegnato il QdC e l'abbiamo analizzato per poi porre le domande (https://github.com/gabrialessi/GestioneEsercizi/blob/master/Analisi/Domande.md).  
Infine ho preparato il repository e iniziato a creare le cartelle e i files iniziali.

Link al repository: https://github.com/gabrialessi/GestioneEsercizi

| Orario | Lavori svolti |
| - | - |
|13:15 - 16:30 | Analisi |

##  Problemi riscontrati e soluzioni adottate

Nessun problema riscontrato.

##  Punto della situazione rispetto alla pianificazione

In linea con la pianificazione.

## Programma di massima per la prossima giornata di lavoro

Analisi del progetto.